const Navbar= ()=.{
    return{
        <div className="Navbar">
            <a href="#">contact us </a>
            <a href="#">about us! </a>
            <a href="#">home ! </a>
        </div>
    }
}

export default Navbar;