const sidebar= () => {
    return{
        <div className="sidebar">
        <span>
        category information
        sidebar
        </span>
        </div>
    };
}
 export default sidebar;